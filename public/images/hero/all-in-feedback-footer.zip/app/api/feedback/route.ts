import { NextResponse } from "next/server";
import { Resend } from "resend";

export const runtime = "nodejs";

type FeedbackPayload = {
  name?: string;
  email?: string;
  category?: string;
  message?: string;
  website?: string;
};

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as FeedbackPayload;

    // Honeypot field. Bots often fill hidden fields.
    if (body.website) {
      return NextResponse.json({ success: true });
    }

    const name = body.name?.trim() || "Anonymous visitor";
    const email = body.email?.trim() || "No email provided";
    const category = body.category?.trim();
    const message = body.message?.trim();

    if (!category || !message || message.length < 10) {
      return NextResponse.json(
        { error: "Category and message are required." },
        { status: 400 },
      );
    }

    if (!process.env.RESEND_API_KEY || !process.env.FEEDBACK_TO_EMAIL) {
      console.error(
        "Missing RESEND_API_KEY or FEEDBACK_TO_EMAIL environment variable.",
      );
      return NextResponse.json(
        { error: "Feedback email is not configured." },
        { status: 503 },
      );
    }

    const resend = new Resend(process.env.RESEND_API_KEY);

    await resend.emails.send({
      from:
        process.env.FEEDBACK_FROM_EMAIL ||
        "All-In Website <onboarding@resend.dev>",
      to: process.env.FEEDBACK_TO_EMAIL,
      replyTo: body.email?.trim() || undefined,
      subject: `[Website Feedback] ${category}`,
      text: [
        `Category: ${category}`,
        `Name: ${name}`,
        `Email: ${email}`,
        "",
        "Message:",
        message,
      ].join("\n"),
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Feedback submission failed:", error);

    return NextResponse.json(
      { error: "Unable to send feedback." },
      { status: 500 },
    );
  }
}
