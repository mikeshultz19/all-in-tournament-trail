import { CheckCircle2 } from "lucide-react";
import Link from "next/link";

import { getTournamentByIdentifier } from "@/lib/tournaments";

interface PublishSuccessPageProps {
  searchParams: Promise<{ tournament?: string | string[] }>;
}

export const dynamic = "force-dynamic";

export default async function PublishSuccessPage({
  searchParams,
}: PublishSuccessPageProps) {
  const params = await searchParams;
  const identifier = Array.isArray(params.tournament)
    ? params.tournament[0]
    : params.tournament;
  const tournament = identifier
    ? await getTournamentByIdentifier(identifier)
    : null;

  return (
    <section className="mx-auto mt-12 max-w-2xl border border-emerald-500/30 bg-emerald-500/10 p-8 text-center">
      <CheckCircle2 aria-hidden="true" className="mx-auto size-12 text-emerald-400" />
      <p className="mt-5 text-xs font-black uppercase tracking-[0.2em] text-emerald-300">
        Tournament Published
      </p>
      <h1 className="mt-2 text-3xl font-black uppercase text-white">
        {tournament?.name ?? "Results are live"}
      </h1>
      <p className="mt-4 text-sm text-neutral-300">
        The tournament results are now available on the public website.
      </p>
      <div className="mt-7 flex flex-col justify-center gap-3 sm:flex-row">
        <Link
          href={identifier ? `/results/${encodeURIComponent(identifier)}` : "/results"}
          className="inline-flex min-h-12 items-center justify-center bg-[#D4A017] px-6 text-xs font-black uppercase tracking-[0.12em] text-black"
        >
          View Public Results
        </Link>
        <Link
          href={identifier ? `/admin/tournament-manager?tournament=${encodeURIComponent(identifier)}` : "/admin/tournament-manager"}
          className="inline-flex min-h-12 items-center justify-center border border-white/15 px-6 text-xs font-black uppercase tracking-[0.12em] text-white"
        >
          Return to Catalyst
        </Link>
      </div>
    </section>
  );
}
