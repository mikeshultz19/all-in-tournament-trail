"use client";

import {
  AlertTriangle,
  CheckCircle2,
  FileUp,
  Loader2,
  UploadCloud,
} from "lucide-react";
import { useRef, useState, useTransition } from "react";

import {
  importWeighfishResultsAction,
  type WeighfishImportState,
} from "@/app/admin/tournament-manager/import/actions";
import {
  parseWeighfishCsv,
  type WeighfishParseResult,
} from "@/lib/weighfishParser";

interface WeighfishCsvUploaderProps {
  tournamentId: string;
}

const initialImportState: WeighfishImportState = {
  status: "idle",
  message: "",
};

function formatCurrency(value: number) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
  }).format(value);
}

export default function WeighfishCsvUploader({
  tournamentId,
}: WeighfishCsvUploaderProps) {
  const inputRef = useRef<HTMLInputElement>(null);

  const [fileName, setFileName] = useState("");
  const [result, setResult] =
    useState<WeighfishParseResult | null>(null);
  const [reading, setReading] = useState(false);
  const [importState, setImportState] =
    useState<WeighfishImportState>(initialImportState);
  const [importing, startImport] = useTransition();

  async function handleFile(file: File | undefined) {
    if (!file) return;

    setReading(true);
    setFileName(file.name);
    setImportState(initialImportState);

    try {
      const csv = await file.text();
      setResult(parseWeighfishCsv(csv));
    } catch {
      setResult(null);
      setImportState({
        status: "error",
        message: "The CSV file could not be read.",
      });
    } finally {
      setReading(false);
    }
  }

  function handleImport() {
    if (!result?.valid || !result.rows.length) {
      return;
    }

    startImport(async () => {
      const response = await importWeighfishResultsAction(
        tournamentId,
        result.rows,
      );

      setImportState(response);
    });
  }

  return (
    <section className="border border-white/10 bg-[#111111] p-5 sm:p-7">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.2em] text-[#D4A017]">
            WeighFish Import
          </p>

          <h2 className="mt-2 text-xl font-black uppercase text-white">
            Upload Tournament CSV
          </h2>

          <p className="mt-2 text-sm leading-6 text-neutral-400">
            Choose the official WeighFish CSV, review the summary,
            and import the results.
          </p>
        </div>

        <FileUp className="size-8 text-[#D4A017]" />
      </div>

      <input
        ref={inputRef}
        type="file"
        accept=".csv,text/csv"
        className="sr-only"
        onChange={(event) => {
          void handleFile(event.target.files?.[0]);
          event.target.value = "";
        }}
      />

      <button
        type="button"
        disabled={reading || importing}
        onClick={() => inputRef.current?.click()}
        className="mt-5 inline-flex min-h-12 items-center gap-2 bg-red-700 px-6 text-sm font-black uppercase tracking-[0.12em] text-white disabled:opacity-60"
      >
        {reading ? (
          <Loader2 className="size-5 animate-spin" />
        ) : (
          <UploadCloud className="size-5" />
        )}

        {reading ? "Reading CSV…" : "Choose WeighFish CSV"}
      </button>

      {fileName && (
        <p className="mt-3 text-sm text-neutral-300">
          Selected: <strong>{fileName}</strong>
        </p>
      )}

      {result?.errors.length ? (
        <div className="mt-5 border border-red-500/40 bg-red-500/10 p-4">
          <p className="font-black uppercase text-red-300">
            CSV Errors
          </p>

          <ul className="mt-2 space-y-1 text-sm text-red-200">
            {result.errors.map((error) => (
              <li key={error}>• {error}</li>
            ))}
          </ul>
        </div>
      ) : null}

      {result?.warnings.length ? (
        <div className="mt-5 border border-amber-500/40 bg-amber-500/10 p-4">
          <p className="flex items-center gap-2 font-black uppercase text-amber-300">
            <AlertTriangle className="size-4" />
            Warnings
          </p>

          <ul className="mt-2 space-y-1 text-sm text-amber-200">
            {result.warnings.map((warning) => (
              <li key={warning}>• {warning}</li>
            ))}
          </ul>
        </div>
      ) : null}

      {result?.valid && (
        <div className="mt-6 space-y-5">
          <div className="grid gap-3 sm:grid-cols-3">
            <SummaryCard
              label="Entries"
              value={String(result.rows.length)}
            />

            <SummaryCard
              label="Champion"
              value={
                result.rows.find((row) => row.place === 1)
                  ?.entryName ?? "Not listed"
              }
            />

            <SummaryCard
              label="Total Payout"
              value={formatCurrency(result.payoutTotals.total)}
            />
          </div>

          <button
            type="button"
            disabled={importing}
            onClick={handleImport}
            className="inline-flex min-h-12 items-center gap-2 bg-[#D4A017] px-6 text-sm font-black uppercase tracking-[0.12em] text-black disabled:opacity-60"
          >
            {importing ? (
              <>
                <Loader2 className="size-5 animate-spin" />
                Importing…
              </>
            ) : (
              <>
                <CheckCircle2 className="size-5" />
                Import Results
              </>
            )}
          </button>
        </div>
      )}

      {importState.message && (
        <p
          className={`mt-5 border px-4 py-3 text-sm font-semibold ${
            importState.status === "success"
              ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-200"
              : "border-red-500/40 bg-red-500/10 text-red-200"
          }`}
        >
          {importState.message}
        </p>
      )}
    </section>
  );
}

function SummaryCard({
  label,
  value,
}: {
  label: string;
  value: string;
}) {
  return (
    <div className="border border-white/10 bg-black/30 p-4">
      <p className="text-xs font-black uppercase tracking-[0.12em] text-neutral-500">
        {label}
      </p>

      <p className="mt-2 font-bold text-white">{value}</p>
    </div>
  );
}