import { CalendarDays, ClipboardList, Trophy } from "lucide-react";
import Image from "next/image";
import Link from "next/link";

import type { LatestTournamentResults } from "@/types/results";

const FALLBACK_RESULTS_IMAGE = "/images/tournament-hero.png";

function formatTournamentDate(value: string): string {
  return new Intl.DateTimeFormat("en-US", {
    timeZone: "America/Chicago",
    month: "long",
    day: "numeric",
    year: "numeric",
  }).format(new Date(value));
}

function placementLabel(place: number): string {
  if (place === 1) return "1ST";
  if (place === 2) return "2ND";
  return "3RD";
}

function formatCurrency(value: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: Number.isInteger(value) ? 0 : 2,
  }).format(value);
}

function ResultsHeader() {
  return (
    <header className="flex items-center gap-3 bg-gradient-to-r from-red-800 via-red-700 to-red-900 px-4 py-3 sm:px-5">
      <Trophy aria-hidden="true" className="size-5 shrink-0 text-white" />
      <h2 className="text-sm font-black uppercase tracking-[0.12em] text-white sm:text-base">
        Latest Tournament Results
      </h2>
    </header>
  );
}

export default function WinnersCircle({
  latestResults,
}: {
  latestResults: LatestTournamentResults | null;
}) {
  const topFinishers = latestResults?.results.entries
    .toSorted((a, b) => a.place - b.place)
    .slice(0, 3);

  return (
    <section
      id="results"
      className="border-b border-zinc-900 bg-[#050505] px-4 py-8 sm:px-6"
    >
      <div className="mx-auto max-w-[1300px]">
        <article className="overflow-hidden rounded-md border border-red-800/80 bg-[#0b0b0b] shadow-[0_18px_45px_rgba(0,0,0,0.28)]">
          <ResultsHeader />

          {!latestResults ? (
            <div className="relative min-h-[320px] overflow-hidden">
              <Image
                src={FALLBACK_RESULTS_IMAGE}
                alt=""
                fill
                sizes="(max-width: 1300px) 100vw, 1300px"
                className="object-cover"
              />
              <div className="absolute inset-0 bg-black/70" />
              <div className="relative z-10 flex min-h-[320px] flex-col items-center justify-center px-6 py-12 text-center">
                <ClipboardList
                  aria-hidden="true"
                  className="size-10 text-white"
                />
                <h3 className="mt-4 text-xl font-black uppercase tracking-tight text-white sm:text-2xl">
                  No Results Available
                </h3>
                <p className="mt-2 text-sm text-neutral-300 sm:text-base">
                  Results will appear here after the next tournament.
                </p>
              </div>
            </div>
          ) : (
            <div className="grid lg:grid-cols-[45%_55%]">
              <div className="relative min-h-[220px] overflow-hidden bg-zinc-950 sm:min-h-[280px] lg:min-h-[350px]">
                <Image
                  src={
                    latestResults.tournamentImage ?? FALLBACK_RESULTS_IMAGE
                  }
                  alt={`${latestResults.tournament.name} tournament`}
                  fill
                  sizes="(max-width: 1024px) 100vw, 585px"
                  className="object-cover"
                />
              </div>

              <div className="flex min-w-0 flex-col px-5 py-5 sm:px-7 sm:py-6">
                <div>
                  <h3 className="text-2xl font-black uppercase leading-tight tracking-tight text-white sm:text-3xl">
                    {latestResults.tournament.name}
                  </h3>
                  {latestResults.tournament.lake && (
                    <p className="mt-1 text-sm font-black uppercase tracking-[0.12em] text-red-500">
                      {latestResults.tournament.lake}
                    </p>
                  )}
                  <p className="mt-3 inline-flex items-center gap-2 text-sm text-neutral-300">
                    <CalendarDays
                      aria-hidden="true"
                      className="size-4 text-red-500"
                    />
                    <time dateTime={latestResults.tournament.tournament_date}>
                      {formatTournamentDate(
                        latestResults.tournament.tournament_date,
                      )}
                    </time>
                  </p>
                </div>

                <div className="mt-5 flex items-center justify-between gap-4 border-l-4 border-red-600 bg-red-950/30 px-4 py-3">
                  <span className="text-[0.65rem] font-black uppercase tracking-[0.12em] text-neutral-300 sm:text-xs">
                    TOTAL PAID OUT TO ANGLERS
                  </span>
                  <strong className="shrink-0 text-xl font-black tabular-nums text-white sm:text-2xl">
                    {formatCurrency(
                      latestResults.results.total_payout +
                        (latestResults.results.bronze_payout ?? 0) +
                        (latestResults.results.silver_payout ?? 0) +
                        (latestResults.results.gold_payout ?? 0) +
                        (latestResults.results.insurance_pot_payout ?? 0),
                    )}
                  </strong>
                </div>

                <ol className="mt-5 grid gap-2">
                  {topFinishers?.map((entry) => (
                    <li
                      key={`${entry.place}-${entry.team}`}
                      className="grid min-w-0 grid-cols-[3.25rem_minmax(0,1fr)_auto] items-center gap-3 border border-white/10 bg-black/35 px-3 py-2.5"
                    >
                      <span
                        className={`inline-flex min-h-7 items-center justify-center rounded-sm px-2 text-[0.65rem] font-black tracking-[0.1em] text-white ${
                          entry.place === 1 ? "bg-red-700" : "bg-zinc-700"
                        }`}
                      >
                        {placementLabel(entry.place)}
                      </span>
                      <span className="min-w-0 truncate text-sm font-bold text-white">
                        {entry.team}
                      </span>
                      <span className="whitespace-nowrap text-right text-sm font-black tabular-nums text-white">
                        {entry.weight.toFixed(2)} lbs
                      </span>
                    </li>
                  ))}
                </ol>

                <Link
                  href={latestResults.completeResultsUrl}
                  className="mt-5 inline-flex min-h-11 w-full items-center justify-center border border-red-600 bg-black/20 px-5 text-xs font-black uppercase tracking-[0.12em] text-white transition hover:bg-red-700 hover:text-white focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-red-500"
                >
                  View Complete Results
                  <span className="ml-2" aria-hidden="true">
                    &gt;
                  </span>
                </Link>
              </div>
            </div>
          )}
        </article>
      </div>
    </section>
  );
}
